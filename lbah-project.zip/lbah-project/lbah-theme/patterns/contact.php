<?php
/** Title: LBAH Contact & Hours
 * Slug: lbah-theme/contact
 * Categories: text
 */ ?>
<!-- wp:heading --><h2>Opening hours</h2><!-- /wp:heading -->
<!-- wp:table --><figure class="wp-block-table"><table><caption>Opening hours (edit to match your business)</caption><thead><tr><th scope="col">Day</th><th scope="col">Hours</th></tr></thead><tbody><tr><th scope="row">Monday–Friday</th><td>9:00–17:00</td></tr><tr><th scope="row">Saturday</th><td>10:00–14:00</td></tr><tr><th scope="row">Sunday</th><td>Closed</td></tr></tbody></table></figure><!-- /wp:table -->
<!-- wp:heading --><h2>Find us</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>Street address, Town. <a href="https://maps.google.com/?q=YOUR+ADDRESS">Open in maps</a></p><!-- /wp:paragraph -->
<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link" href="tel:+9770000000000">Call</a></div><!-- /wp:button --><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link" href="mailto:hello@example.com">Email</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
