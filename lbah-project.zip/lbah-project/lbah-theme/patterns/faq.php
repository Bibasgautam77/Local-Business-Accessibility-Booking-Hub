<?php
/** Title: LBAH FAQ
 * Slug: lbah-theme/faq
 * Categories: text
 */ ?>
<!-- wp:details --><details class="wp-block-details"><summary>How do I book?</summary><p>Use the booking page. We reply within one business day to confirm a time.</p></details><!-- /wp:details -->
<!-- wp:details --><details class="wp-block-details"><summary>Is my request a confirmed appointment?</summary><p>No. It is confirmed only when we reply.</p></details><!-- /wp:details -->
<!-- wp:details --><details class="wp-block-details"><summary>What happens to my data?</summary><p>We use it only to answer your request. See the privacy notice.</p></details><!-- /wp:details -->
<!-- wp:details --><details class="wp-block-details"><summary>Is the venue accessible?</summary><p>Edit this answer to describe step-free access, parking and other support.</p></details><!-- /wp:details -->
