# Accessibility checklist (target: WCAG 2.2 AA)

Copyright © 2026 Bibas Gautam. All rights reserved.

Mark each item Pass / Fail with notes after testing.

- [ ] Skip link is first tab stop and works
- [ ] Every page has one h1 and a logical heading order
- [ ] All interactive elements reachable and operable by keyboard
- [ ] Focus outline always visible
- [ ] Every form field has a visible label; required fields marked in text
- [ ] Errors summarised, linked to fields, and focus moves to the summary
- [ ] Errors not conveyed by colour alone; contrast ≥ 4.5:1
- [ ] Autocomplete attributes on name, email, phone
- [ ] Confirmation message announced and focused
- [ ] Touch targets ≥ 44px; no horizontal scroll at 320px width
- [ ] Zoom to 200% without loss of content
- [ ] Tables have caption and header cells; FAQ uses details/summary
- [ ] Reduced-motion respected
- [ ] Tested with NVDA or VoiceOver, plus Lighthouse/axe
