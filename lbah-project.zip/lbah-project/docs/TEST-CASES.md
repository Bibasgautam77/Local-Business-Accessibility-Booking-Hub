# Form test cases

Copyright © 2026 Bibas Gautam. All rights reserved.

| # | Input | Expected |
|---|---|---|
| 1 | All fields valid, consent ticked | Confirmation shown and focused; request saved; admin email sent |
| 2 | Empty submit | Summary lists name, email, service, date, consent errors; focus on summary |
| 3 | Email `abc` | "Enter a valid email address…" on email field |
| 4 | Phone `abc!` | Phone format error; blank phone accepted |
| 5 | Date in the past | "Choose today or a future date." |
| 6 | Date `31-12-2026` | Format error |
| 7 | Service value tampered | "Choose a service from the list." |
| 8 | Consent unticked | Consent error |
| 9 | Message over 1000 characters | Length error |
| 10 | Honeypot filled | Generic failure, nothing saved |
| 11 | Submit within 3 seconds | Generic failure |
| 12 | Missing or invalid nonce | Generic failure |
| 13 | 6th submission from one IP within an hour | Generic failure |
| 14 | Keyboard only, then screen reader | Full flow completes; errors announced |
| 15 | 320px and 375px mobile layouts | No overflow; call bar usable |
| 16 | Script tags in name/message | Stored and displayed escaped |
