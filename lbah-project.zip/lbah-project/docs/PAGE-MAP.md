# Page map and user tasks

Copyright © 2026 Bibas Gautam. All rights reserved.

```mermaid
flowchart TD
  H[Home] --> S[Services archive]
  S --> D[Service detail]
  D --> B[Booking]
  H --> B
  H --> F[FAQ]
  H --> C[Contact]
  F --> B
  C --> B
```

| User | Top tasks |
|---|---|
| First-time mobile visitor | Understand a service, tap to call, find hours |
| Screen-reader / keyboard user | Complete the form, understand and fix errors |
| Busy returning customer | Request a slot fast, check hours and location |
