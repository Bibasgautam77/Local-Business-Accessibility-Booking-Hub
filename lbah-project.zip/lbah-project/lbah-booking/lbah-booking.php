<?php
/**
 * Plugin Name: Local Business Booking Hub
 * Description: Services post type, categories, and an accessible appointment request form ([lbah_booking_form]).
 * Author: Bibas Gautam
 * Copyright: 2026 Bibas Gautam. All rights reserved.
 * Version: 1.0.0
 * Text Domain: lbah
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ---------- Content model ---------- */
add_action( 'init', function () {
	register_post_type( 'lbah_service', [
		'labels'       => [ 'name' => 'Services', 'singular_name' => 'Service' ],
		'public'       => true,
		'has_archive'  => 'services',
		'rewrite'      => [ 'slug' => 'services' ],
		'menu_icon'    => 'dashicons-clipboard',
		'show_in_rest' => true,
		'supports'     => [ 'title', 'editor', 'excerpt', 'thumbnail' ],
	] );
	register_taxonomy( 'lbah_service_category', 'lbah_service', [
		'labels'       => [ 'name' => 'Service Categories', 'singular_name' => 'Service Category' ],
		'hierarchical' => true,
		'show_in_rest' => true,
		'rewrite'      => [ 'slug' => 'service-category' ],
	] );
	// Private store for booking requests (admin-only, never public).
	register_post_type( 'lbah_request', [
		'labels'   => [ 'name' => 'Booking Requests', 'singular_name' => 'Booking Request' ],
		'public'   => false,
		'show_ui'  => true,
		'menu_icon' => 'dashicons-calendar-alt',
		'supports' => [ 'title' ],
		'capabilities' => [ 'create_posts' => 'do_not_allow' ],
		'map_meta_cap' => true,
	] );
} );

register_activation_hook( __FILE__, function () {
	do_action( 'init' );
	flush_rewrite_rules();
} );

/* ---------- Form helpers ---------- */
function lbah_time_token() {
	$ts = time();
	return $ts . '.' . wp_hash( 'lbah' . $ts );
}
function lbah_token_age( $token ) {
	$parts = explode( '.', (string) $token );
	if ( count( $parts ) !== 2 || ! hash_equals( wp_hash( 'lbah' . $parts[0] ), $parts[1] ) ) { return false; }
	return time() - (int) $parts[0];
}
function lbah_field( $id, $label, $input, $error, $hint = '', $required = true ) {
	$desc = [];
	if ( $hint )  { $desc[] = "$id-hint"; }
	if ( $error ) { $desc[] = "$id-error"; }
	$out  = '<p class="lbah-field' . ( $error ? ' has-error' : '' ) . '">';
	$out .= '<label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . ( $required ? ' <span aria-hidden="true">*</span><span class="screen-reader-text"> (required)</span>' : ' (optional)' ) . '</label>';
	if ( $hint )  { $out .= '<span id="' . $id . '-hint" class="lbah-hint">' . esc_html( $hint ) . '</span>'; }
	if ( $error ) { $out .= '<span id="' . $id . '-error" class="lbah-error">' . esc_html( $error ) . '</span>'; }
	$attrs = ' id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '"'
		. ( $required ? ' aria-required="true"' : '' )
		. ( $error ? ' aria-invalid="true"' : '' )
		. ( $desc ? ' aria-describedby="' . esc_attr( implode( ' ', $desc ) ) . '"' : '' );
	return $out . str_replace( '%ATTRS%', $attrs, $input ) . '</p>';
}

/* ---------- Shortcode: render + process ---------- */
add_shortcode( 'lbah_booking_form', function () {
	$errors = [];
	$v = [ 'lbah_name' => '', 'lbah_email' => '', 'lbah_phone' => '', 'lbah_service' => 0, 'lbah_date' => '', 'lbah_message' => '', 'lbah_consent' => '' ];

	if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['lbah_submit'] ) ) {
		$p = wp_unslash( $_POST );
		$v['lbah_name']    = sanitize_text_field( $p['lbah_name'] ?? '' );
		$v['lbah_email']   = sanitize_email( $p['lbah_email'] ?? '' );
		$v['lbah_phone']   = sanitize_text_field( $p['lbah_phone'] ?? '' );
		$v['lbah_service'] = absint( $p['lbah_service'] ?? 0 );
		$v['lbah_date']    = sanitize_text_field( $p['lbah_date'] ?? '' );
		$v['lbah_message'] = sanitize_textarea_field( $p['lbah_message'] ?? '' );
		$v['lbah_consent'] = ! empty( $p['lbah_consent'] ) ? '1' : '';

		// Spam controls: nonce, honeypot, minimum fill time, per-IP rate limit.
		$ip_key = 'lbah_rl_' . md5( $_SERVER['REMOTE_ADDR'] ?? '' );
		$age    = lbah_token_age( $p['lbah_ts'] ?? '' );
		if ( ! wp_verify_nonce( $p['lbah_nonce'] ?? '', 'lbah_submit' ) || ! empty( $p['lbah_website'] ) || false === $age || $age < 3 || (int) get_transient( $ip_key ) >= 5 ) {
			$errors['form'] = 'We could not send your request. Please wait a moment, reload the page and try again, or call us instead.';
		}

		// Field validation: messages say what is wrong and how to fix it.
		if ( strlen( $v['lbah_name'] ) < 2 ) { $errors['lbah_name'] = 'Enter your full name.'; }
		if ( ! is_email( $v['lbah_email'] ) ) { $errors['lbah_email'] = 'Enter a valid email address, for example name@example.com.'; }
		if ( $v['lbah_phone'] && ! preg_match( '/^[0-9+()\-\s.]{7,20}$/', $v['lbah_phone'] ) ) { $errors['lbah_phone'] = 'Use only numbers, spaces, and + ( ) - characters.'; }
		if ( ! $v['lbah_service'] || 'lbah_service' !== get_post_type( $v['lbah_service'] ) || 'publish' !== get_post_status( $v['lbah_service'] ) ) { $errors['lbah_service'] = 'Choose a service from the list.'; }
		$d = DateTime::createFromFormat( 'Y-m-d', $v['lbah_date'] );
		if ( ! $d || $d->format( 'Y-m-d' ) !== $v['lbah_date'] ) { $errors['lbah_date'] = 'Enter a date in the format YYYY-MM-DD.'; }
		elseif ( $v['lbah_date'] < wp_date( 'Y-m-d' ) ) { $errors['lbah_date'] = 'Choose today or a future date.'; }
		if ( strlen( $v['lbah_message'] ) > 1000 ) { $errors['lbah_message'] = 'Keep your message under 1000 characters.'; }
		if ( ! $v['lbah_consent'] ) { $errors['lbah_consent'] = 'Please agree to the privacy notice so we can contact you.'; }

		if ( ! $errors ) {
			set_transient( $ip_key, (int) get_transient( $ip_key ) + 1, HOUR_IN_SECONDS );
			$id = wp_insert_post( [
				'post_type'   => 'lbah_request',
				'post_status' => 'private',
				'post_title'  => sprintf( '%s – %s', $v['lbah_name'], $v['lbah_date'] ),
				'meta_input'  => [
					'email' => $v['lbah_email'], 'phone' => $v['lbah_phone'], 'service_id' => $v['lbah_service'],
					'date' => $v['lbah_date'], 'message' => $v['lbah_message'],
				],
			] );
			wp_mail( get_option( 'admin_email' ), 'New booking request: ' . $v['lbah_name'],
				sprintf( "Name: %s\nEmail: %s\nPhone: %s\nService: %s\nDate: %s\n\n%s", $v['lbah_name'], $v['lbah_email'], $v['lbah_phone'], get_the_title( $v['lbah_service'] ), $v['lbah_date'], $v['lbah_message'] ) );
			return '<div class="lbah-confirm" role="status" tabindex="-1" id="lbah-confirm"><h2>Request received</h2><p>Thank you, ' . esc_html( $v['lbah_name'] ) . '. We will reply to ' . esc_html( $v['lbah_email'] ) . ' within one business day to confirm a time. This is a request, not a confirmed appointment.</p></div><script>document.getElementById("lbah-confirm").focus();</script>';
		}
	}

	$services = get_posts( [ 'post_type' => 'lbah_service', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ] );
	$opts = '<option value="">Select a service</option>';
	foreach ( $services as $s ) { $opts .= '<option value="' . $s->ID . '"' . selected( $v['lbah_service'], $s->ID, false ) . '>' . esc_html( $s->post_title ) . '</option>'; }

	$e = fn( $k ) => $errors[ $k ] ?? '';
	ob_start();
	if ( $errors ) {
		echo '<div class="lbah-summary" role="alert" tabindex="-1" id="lbah-summary"><h2>Please fix ' . ( count( $errors ) > 1 ? 'these problems' : 'this problem' ) . '</h2><ul>';
		foreach ( $errors as $k => $m ) { echo '<li>' . ( 'form' === $k ? '' : '<a href="#' . esc_attr( $k ) . '">' ) . esc_html( $m ) . ( 'form' === $k ? '' : '</a>' ) . '</li>'; }
		echo '</ul></div><script>document.getElementById("lbah-summary").focus();</script>';
	}
	echo '<form method="post" class="lbah-form" novalidate><p class="lbah-hint">Fields marked * are required.</p>';
	echo lbah_field( 'lbah_name', 'Full name', '<input type="text" autocomplete="name" value="' . esc_attr( $v['lbah_name'] ) . '"%ATTRS%>', $e( 'lbah_name' ) );
	echo lbah_field( 'lbah_email', 'Email', '<input type="email" autocomplete="email" value="' . esc_attr( $v['lbah_email'] ) . '"%ATTRS%>', $e( 'lbah_email' ) );
	echo lbah_field( 'lbah_phone', 'Phone', '<input type="tel" autocomplete="tel" value="' . esc_attr( $v['lbah_phone'] ) . '"%ATTRS%>', $e( 'lbah_phone' ), '', false );
	echo lbah_field( 'lbah_service', 'Service', '<select%ATTRS%>' . $opts . '</select>', $e( 'lbah_service' ) );
	echo lbah_field( 'lbah_date', 'Preferred date', '<input type="date" min="' . esc_attr( wp_date( 'Y-m-d' ) ) . '" value="' . esc_attr( $v['lbah_date'] ) . '"%ATTRS%>', $e( 'lbah_date' ), 'Format: YYYY-MM-DD' );
	echo lbah_field( 'lbah_message', 'Anything we should know?', '<textarea rows="4" maxlength="1000"%ATTRS%>' . esc_textarea( $v['lbah_message'] ) . '</textarea>', $e( 'lbah_message' ), 'Access needs, questions, or preferred times.', false );
	echo '<p class="lbah-field' . ( $e( 'lbah_consent' ) ? ' has-error' : '' ) . '"><input type="checkbox" id="lbah_consent" name="lbah_consent" value="1"' . checked( $v['lbah_consent'], '1', false ) . ' aria-required="true"' . ( $e( 'lbah_consent' ) ? ' aria-invalid="true" aria-describedby="lbah_consent-error"' : '' ) . '> <label for="lbah_consent">I agree to the <a href="' . esc_url( get_privacy_policy_url() ) . '">privacy notice</a>. We use your details only to reply to this request. <span class="screen-reader-text">(required)</span></label>' . ( $e( 'lbah_consent' ) ? '<span id="lbah_consent-error" class="lbah-error">' . esc_html( $e( 'lbah_consent' ) ) . '</span>' : '' ) . '</p>';
	// Honeypot: hidden from sighted users and assistive tech.
	echo '<div style="position:absolute;left:-9999px" aria-hidden="true"><label>Leave this empty<input type="text" name="lbah_website" tabindex="-1" autocomplete="off"></label></div>';
	wp_nonce_field( 'lbah_submit', 'lbah_nonce' );
	echo '<input type="hidden" name="lbah_ts" value="' . esc_attr( lbah_time_token() ) . '">';
	echo '<button type="submit" name="lbah_submit" value="1">Request appointment</button></form>';
	return ob_get_clean();
} );

/* ---------- Minimal styles (visible focus, error contrast) ---------- */
add_action( 'wp_head', function () {
	echo '<style>.lbah-form input:not([type=checkbox]),.lbah-form select,.lbah-form textarea{display:block;width:100%;max-width:32rem;min-height:2.75rem;padding:.5rem;font:inherit}.lbah-form :focus,.lbah-summary:focus,.lbah-confirm:focus{outline:3px solid #1a4fd6;outline-offset:2px}.lbah-error{display:block;color:#a30000;font-weight:600}.has-error input,.has-error select,.has-error textarea{border:2px solid #a30000}.lbah-summary{border:2px solid #a30000;padding:1rem;margin-bottom:1rem}.lbah-hint{display:block;color:#444}.lbah-form button{min-height:2.75rem;padding:.5rem 1.5rem;font:inherit}</style>';
} );
